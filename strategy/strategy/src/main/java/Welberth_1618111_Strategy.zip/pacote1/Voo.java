
package pacote1;

/**
 *
 * @author welbe
 */
public class Voo {
    
    protected int distancia;
	
	protected String status;
	
	protected int numero;
	
	
	public int getNumero() {
		return this.numero;
	}
	
	public int getDistancia() {
		return this.distancia;
	}
    
    
}
