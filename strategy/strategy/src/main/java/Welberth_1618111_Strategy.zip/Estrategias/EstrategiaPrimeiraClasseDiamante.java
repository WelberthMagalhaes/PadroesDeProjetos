
package Estrategias;

/**
 *
 * @author welbe
 */
public class EstrategiaPrimeiraClasseDiamante  implements EstrategiaDePontuacao{

    @Override
    public int calcularPontuacao(int distanciaDeVoo) {
        return distanciaDeVoo;
    }
    
}
