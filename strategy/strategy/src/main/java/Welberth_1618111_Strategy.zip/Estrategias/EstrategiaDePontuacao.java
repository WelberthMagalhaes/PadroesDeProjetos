
package Estrategias;

/**
 *
 * @author welbe
 */
public interface EstrategiaDePontuacao {
    public int calcularPontuacao(int distanciaDeVoo);
}
